# WEB 200 Fundamentals of Web Development
## Contributors
* Professor Richard Krasso
* Alex Thomas
